/*
 Date : 2020.05.08
 Author : KIM SUNG JIN
 Description : ex02_day01
 version : 1.0
 */
package java0508;

public class ex02_day01 {

	public static void main(String[] args) {
		String name;
		name = "김성진";
		String birth = "0410";
		int age = 26;
		String adr = "만석동";		//주소 : ~동
		String phone = "01051732883";
		String email = "zzrkdl@naver.com";
		String hobby = "게임";
		String speciality = "운동";
		char blood;
		
		String number1;
		String number2;
		String number3;
		
		System.out.println(" 제 이름은" + name + " 입니다. ");
		System.out.println(" 제 나이는" + age  + "입니다");
		System.out.println(" 제 생일은" + birth + "입니다");
		System.out.println(" 제 주소는" + adr  + "입니다");
		System.out.println(" 제 핸드폰 번호는" + phone + "입니다");
		System.out.println(" 제 메일은" + email + "입니다");
		System.out.println(" 제 취미는" + hobby + "입니다");
		System.out.println(" 제 특기는" + speciality + "입니다");

	}

}
