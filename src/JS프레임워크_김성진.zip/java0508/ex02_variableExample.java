package java0508;

public class ex02_variableExample {

	public static void main(String[] args) {
		// 변수이름
		// 1, 카멜표기법 : 시작은 소문자, 다른뜻 단어가
		// 등장할때 대문자를 사용해서 표기
		// ex) jInfo , 학생수를 표시 =>> numberOfStudent
		// 2. 변수 이름은 영문자, 숫자, 특수문자(_(언더바),$) 사용가능 하다
		// 3. 변수명은 숫자로 시작할 수 없다.
		// 4. 변수명은 예약어(int, double 등) 사용할 수 없다.

		 int 123;
		 int 1number;
		 int number1;
		 int _number;
		 int number_;
		 int $number;
		 int number$;
		 int #number;
		 int number#;
		 int number&;
		 
	}

}
