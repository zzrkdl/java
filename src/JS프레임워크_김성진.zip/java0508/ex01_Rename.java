/*
		Date	:	2020.05.08
		Author	:	sungjin
		Description	:	 Java 기본설정
		Version	:	1.0
*/
package java0508;

public class ex01_Rename {

	public static void main(String[] args) {
		// 주석달기
		//  1. 한줄 주석처리
		/*  2. 범위 주석처리 */
		
		// ; =>> 문장의 마침표 역활
		System.out.println("zzrkdl");
		System.out.println("입니다");
		
		//sysout 입력 후 [ctrl] + [space]
		System.out.println();
		System.out.println("sysout 입력 후 [ctrl]+[space]");
		
		// 실행 (Run) =>> [ctrl] + [F11]
		
		// 저장 (save) =>> [ctrl] + [s]
		// 모두저장 (all save) =>> [ctrl] + [shift] +[s]

		// 글자 크게	: [ctrl]+[+]
		// 글자 작게	: [ctrl]+[-]
		/*
		  클래스 이름 바꾸기 
		 '클래스명 ' 오른쪽 마우스 클릭 → Refactor → Rename
		
				프로젝트, 패키지 동일
		*/
	}

}
