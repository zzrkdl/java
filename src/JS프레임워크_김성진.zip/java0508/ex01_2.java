/*
 Date : 
 Author :
 Description :
 version :
 */

package java0508;

public class ex01_2 {

public static void main(String[] args) {
System.out.println("들여쓰기 연습");
System.out.println("[Ctrl]+[Shift]+[F]");
	}

}
